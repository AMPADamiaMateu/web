<?php

/**
* @author    JoomShaper http://www.joomshaper.com
* @copyright Copyright (C) 2010 - 2013 JoomShaper
* @license   http://www.gnu.org/licenses/gpl-2.0.html GNU/GPLv2
*/

defined('_JEXEC') or die;

// Requred Componenet and module helper
JLoader::register('ModSpSoccerRecentResultHelper', JPATH_ROOT . '/modules/mod_sp_soccer_recent_results/helper.php');

jimport('joomla.form.formfield');
jimport('joomla.filesystem.folder');
jimport('joomla.filesystem.file');

class JFormFieldTournaments extends JFormField {

    protected $type = 'tournaments';


    protected function getInput(){

        // Get Tournaments
        $db = JFactory::getDbo();
        $query = $db->getQuery(true);

        // Select all records from the user profile table where key begins with "custom.".
        $query->select($db->quoteName(array('spsoccer_tournament_id', 'title', 'slug' )));
        $query->from($db->quoteName('#__spsoccer_tournaments'));
        $query->where($db->quoteName('enabled')." = 1");
        $query->order('ordering ASC');

        $db->setQuery($query);
        $results = $db->loadObjectList();
        $tournament_list = $results;


        foreach($tournament_list as $tournament){
            $options[] = JHTML::_( 'select.option', $tournament->spsoccer_tournament_id, $tournament->title );

            //print_r($tournament);
        }

        return JHTML::_('select.genericlist', $options, 'jform[params]['.$this->fieldname.']', '', 'value', 'text', $this->value);
    }
}
