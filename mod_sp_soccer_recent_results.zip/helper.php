<?php
/**
 * @package     SP Soccer
 * @subpackage  mod_spsimpleportfolio
 *
 * @copyright   Copyright (C) 2010 - 2015 JoomShaper. All rights reserved.
 * @license     GNU General Public License version 2 or later.
 */

defined('_JEXEC') or die;

class ModSpSoccerRecentResultHelper {

	// Get Recent Matches
	public static function getRecentMatches($params) {
		$db = JFactory::getDbo();
		$query = $db->getQuery(true);

		$query->select($db->quoteName(array('a.spsoccer_match_id', 'a.title', 'a.slug', 'a.date', 'a.time', 'a.teamone_score', 'a.teamtwo_score', 'a.teamone', 'a.teamtwo' )));
		$query->select($db->quoteName('b.title', 'teamone_name'));
		$query->select($db->quoteName('b.logo', 'teamone_logo'));
		$query->select($db->quoteName('c.title', 'teamtwo_name'));
		$query->select($db->quoteName('c.logo', 'teamtwo_logo'));
    	$query->from($db->quoteName('#__spsoccer_matches', 'a'));
    	$query->join('LEFT', $db->quoteName('#__spsoccer_gameteams', 'b') . ' ON (' . $db->quoteName('a.teamone') . ' = ' . $db->quoteName('b.spsoccer_gameteam_id') . ')');
    	$query->join('LEFT', $db->quoteName('#__spsoccer_gameteams', 'c') . ' ON (' . $db->quoteName('a.teamtwo') . ' = ' . $db->quoteName('c.spsoccer_gameteam_id') . ')');

    	$query->where($db->quoteName('a.enabled')." = 1");
    	$query->where($db->quoteName('a.played_game')." = 1");
    	$query->where($db->quoteName('a.spsoccer_tournament_id')." = ".$params->get('tournament'));
		$query->order('a.date DESC');

    	$query->setLimit($params->get('limit', 6));

		$db->setQuery($query);
		
		$results = $db->loadObjectList();

		return $results;
	}


}
