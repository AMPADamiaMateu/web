<?php
/**
* @package   SP Soccer
* @author    JoomShaper http://www.joomshaper.com
* @copyright Copyright (C) 2010 - 2017 JoomShaper. All rights reserved.
* @license   http://www.gnu.org/licenses/gpl-2.0.html GNU/GPLv2 or later.
*/


// no direct access
defined('_JEXEC') or die;

?>

<div class="sp-recent-result <?php echo $moduleclass_sfx . ' ' . $module->id; ?>">

    <?php if (!empty($matches)) { ?>
    <div id="club-rank-<?php echo $module->id; ?>" class="carousel-club-rank carousel slide" data-ride="rr-carousel">
        <!-- Controls -->
        <div class="carousel-controls">
          <a class="left rr-control" data-target="#club-rank-<?php echo $module->id; ?>" role="button" data-slide="prev">
            <i class="sp-soccer-angle-left"></i>
          </a>
          <a class="right rr-control" data-target="#club-rank-<?php echo $module->id; ?>" role="button" data-slide="next">
            <i class="sp-soccer-angle-right"></i>
          </a>
        </div>
        <!-- Wrapper for slides -->
        <div class="carousel-inner" role="listbox">

            <?php foreach(array_chunk($matches, $row) as $key => $matches) { ?>


                <div class="item <?php echo ($key == 0) ? 'active' : '' ?>">

                    <?php foreach ($matches as $matchItem) { ?>

                        <div class="soccer-recent-result">

                            <div class="clubnames">
                                <span class="text-left"><?php echo $matchItem->title; ?></span>
                                <span class="pull-right"><?php echo JHtml::date($matchItem->date, 'd M Y'); ?></span>
                            </div>

                            <div class="soccer-recent-result-item">
                                <div class="text-left soccer-recent-result-list">
                                    <img class="img-responsive" src="<?php echo $matchItem->teamone_logo; ?>" alt="<?php echo $matchItem->teamone_name; ?>">
                                    <?php echo $matchItem->teamone_name; ?>
                                </div>
                                <div class="text-center soccer-recent-result-list">
                                    <span class="goal"><?php echo $matchItem->teamone_score; ?></span> - <span class="goal"><?php echo $matchItem->teamtwo_score; ?></span>
                                </div>
                                <div class="text-center soccer-recent-result-list">
                                    <img class="img-responsive" src="<?php echo $matchItem->teamtwo_logo; ?>" alt="<?php echo $matchItem->teamtwo_name; ?>">
                                    <?php echo $matchItem->teamtwo_name; ?>
                                </div>
                            </div>

                        </div> <!-- /.soccer-recent-result -->

                    <?php } // end:: foreach $matches  ?>

                </div> <!-- /.item -->
            <?php } // end:: array_chunk  ?>
        </div> <!-- /.carousel-inner -->

    </div> <!-- /.carousel-rank -->


    <?php } else{ ?>
      <div class="module-content">
        <p>No item found in this tournament</p>
      </div>
  <?php } // end:: else ?>

</div><!--/.sp-recent-result-->
