<?php
/**
* @author    JoomShaper http://www.joomshaper.com
* @copyright Copyright (C) 2010 - 2013 JoomShaper
* @license   http://www.gnu.org/licenses/gpl-2.0.html GNU/GPLv2
*/

// no direct access
defined('_JEXEC') or die('Restricted access');

// Requred Componenet and module helper
JLoader::register('SpsoccerHelper', JPATH_ROOT . '/components/com_spsoccer/helpers/helper.php');
JLoader::register('ModSpSoccerRecentResultHelper', __DIR__ . '/helper.php');


// load css
$doc = JFactory::getDocument();
$doc->addStylesheet( JURI::base(true) . '/modules/mod_sp_soccer_recent_results/assets/css/recent-result.css' );
// load fonts from components
$doc->addStylesheet( JURI::base(true) . '/components/com_spsoccer/assets/css/soccer-font.css' );
$doc->addScript( JURI::base(true) . '/modules/mod_sp_soccer_recent_results/assets/js/recent-result.js' );

// Get Module class sfx
$moduleclass_sfx = $params->get('moduleclass_sfx');

// Get item limit
$limit           = $params->get('limit', 6);
// Get row limit
$row             = $params->get('row', 3);

// Get Matches
$matches = ModSpSoccerRecentResultHelper::getRecentMatches($params);

foreach ($matches as &$match) {
	$match->teamone_logo = SpsoccerHelper::hasImg($match->teamone_logo);
	$match->teamtwo_logo = SpsoccerHelper::hasImg($match->teamtwo_logo);
}


require( JModuleHelper::getLayoutPath('mod_sp_soccer_recent_results') );
