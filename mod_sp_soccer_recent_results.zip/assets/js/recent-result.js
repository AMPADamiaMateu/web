/**
* @package   SP Soccer
* @author    JoomShaper http://www.joomshaper.com
* @copyright Copyright (C) 2010 - 2017 JoomShaper. All rights reserved.
* @license   http://www.gnu.org/licenses/gpl-2.0.html GNU/GPLv2 or later.
*/

jQuery(function($) { 'use strict'
    if ( $( ".carousel-recent-result" ).length ) {
      $('.carousel-recent-result').each(function(e) {
          var self = $(this);
          var carouselId = self.attr('id');
          // Get carousel id
          var $rrCarousel = $('#'+ carouselId +'');
          // carrousel
          $rrCarousel.carousel();
          // Prev
          self.find('.left.rr-control').click(function(){
              $rrCarousel.carousel('prev');
          });
          // Prev
          self.find(".right.rr-control").click(function(){
              $rrCarousel.carousel('next');
          });
        });
    }
});
